/*****************************************
 * CS1010X --- Programming Methodology  *
 *                                       *
 *   Mission 17, Question 1 Template     *
 *****************************************/

#include <stdio.h>

#define MAX_LEN 80

void fill(char matrix[MAX_LEN][MAX_LEN], char c) {
    int row, col;
    for (row = 0; row < MAX_LEN; ++row) {
        for (col = 0; col < MAX_LEN; ++col) {
            matrix[row][col] = c;
        }
    }
}

void print(char matrix[MAX_LEN][MAX_LEN], int length) {
    int row, col;
    for (col = 0; col < length + 2; ++col) {
        printf("-");
    }
    printf("\n");
    for (row = 0; row < length; ++row) {
        printf("|");
        for (col = 0; col < length; ++col) {
            printf("%c", matrix[row][col]);
        }
        printf("|\n");
    }
    for (col = 0; col < length + 2; ++col) {
        printf("-");
    }
    printf("\n");
}

void spiral(char matrix[MAX_LEN][MAX_LEN], int length, char *text) {
    /************
     *  Task 1  *
     ************

     Parameters:
        matrix - 2D character matrix to fill.
        length - Length of the square matrix to fill. Only row 0 up to
                 row (length - 1) and column 0 up to column (length - 1)
                 will be processed. Take reference from the 'print' function.
                 Length will always be an even +ve number and at most MAX_LEN.
        text   - String to fill the matrix with.

     You are to fill the matrix with characters from the given text in a
     clockwise sequence, starting from the top-left corner, spiraling inwards
     to the center of the matrix. Note that the size of the matrix is limited
     to the given length (MAX_LEN is only for allocating sufficient memory).

     The text string should be used repeatedly if there are not enough
     characters in the text to fill the entire matrix, i.e.
     strlen(text) < length * length. See below for the expected output.
    */
}

int main(void) {
    char matrix[MAX_LEN][MAX_LEN] = {{'a'}};
    fill(matrix, ' ');
    spiral(matrix, 10, ".... . ._.. .__. __ .");
    print(matrix, 10);

    spiral(matrix, 20, "\\/");
    spiral(matrix, 14, "TheQuickBrownFoxJumpsOverTheLazyDog");
    print(matrix, 21);
    return 0;
}

/*
 EXPECTED OUTPUT:

    ------------
    |.... . ._.|
    |_. __ ....|
    |_.... . . |
    |..........|
    |    ._ _ _|
    |.__.._..._|
    |.__._. . .|
    |_  .__. . |
    |..__. ..__|
    | . ..... _|
    ------------
    -----------------------
    |TheQuickBrownF\/\/\/ |
    |JumpsOverTheLo/\/\/\ |
    |xTheLazyDogTax\/\/\/ |
    |orheLazyDoghzJ/\/\/\ |
    |FeTpsOverTTeyu\/\/\/ |
    |nvrmuickBhhQDm/\/\/\ |
    |wOeuQJumreeuop\/\/\/ |
    |osvJexspoLQigs/\/\/\ |
    |rpOxhoFnwaucTO\/\/\/ |
    |BmsoTgoDyzikhv/\/\/\ |
    |kupFnworBkcBee\/\/\/ |
    |cJmuJxoFnworQr/\/\/\ |
    |ixoFnworBkciuT\/\/\/ |
    |uQehTgoDyzaLeh/\/\/\ |
    |\/\/\/\/\/\/\/\/\/\/ |
    |/\/\/\/\/\/\/\/\/\/\ |
    |\/\/\/\/\/\/\/\/\/\/ |
    |/\/\/\/\/\/\/\/\/\/\ |
    |\/\/\/\/\/\/\/\/\/\/ |
    |/\/\/\/\/\/\/\/\/\/\ |
    |                     |
    -----------------------
*/
